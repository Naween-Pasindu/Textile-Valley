rm(list=ls())

library(data.table)

setwd("~/Shares/NCCT_ToxCast/Filer/NIEHS_Project/All_Materials/")

chem <- fread("Dashboard_chem_info_141218.csv", header = TRUE)
setkey(chem,casrn)

tc_export <- "ToxCast_Summary_Files"
ga_file <- file.path(tc_export, "AllResults_modl_ga_Matrix_141121.csv")
td_file <- file.path(tc_export, "AllResults_tested_Matrix_141121.csv")
zs_file <- file.path(tc_export, "AllResults_zscore_Matrix_141121.csv")
hc_file <- file.path(tc_export, "AllResults_hitc_Matrix_141121.csv")
ga <- data.matrix(read.csv(ga_file, header = TRUE, row.names = 1))
td <- data.matrix(read.csv(td_file, header = TRUE, row.names = 1))
zs <- data.matrix(read.csv(zs_file, header = TRUE, row.names = 1))
hc <- data.matrix(read.csv(hc_file, header = TRUE, row.names = 1))

ga <- 10^ga
ga[hc == 0] <- 1e6
ga[is.na(ga) & td == 1] <- 1e6
ga[zs <= 3] <- 1e6
ga <- -log10(ga/1e6)

zs[zs < 0] <- 0
zs[is.na(zs)] <- 1

ga <- ga*zs

aes <- fread(file.path(tc_export, "Assay_Summary_141121.csv"), header = TRUE)

rar_sub <- ga[ , aes[aeid %in% c(71, 136:138, 723), unique(aenm)]]
rar_scr <- apply(rar_sub, 1, sum, na.rm = TRUE)
scale_func <- function(x) (x - min(x))/diff(range(x))
rar_scr <- scale_func(rar_scr)

chem[ , code := paste0("C", gsub("\\s|-|_", "", casrn))]
setkey(chem, code)
rar_scr <- rar_scr[chem$code]
chem[ , RAR_score := rar_scr]

setkey(chem, casrn)

files <- dir(file.path("Outputs"), "summary")

for (i in files) {
  
  print(i)
  temp <- fread(file.path("Outputs", i), header = TRUE)
  setkey(temp, CASRN)
  
  temp <- chem[temp]
  setnames(temp, "casrn", "CASRN")
    
  setcolorder(temp, 
              c(names(temp)[!names(temp) %in% names(chem)],
                names(temp)[ names(temp) %in% names(chem)]))
  
  temp[ , CASRN := paste0(CASRN,".")]
  setorder(temp, -score)
  write.csv(temp, 
            file.path("Outputs", sub("summary", "cheminfo", i)),
            row.names = FALSE)
  
}
