rm(list=ls())
library(data.table)

## Set working directory to All_Materials
setwd("~/Shares/NCCT_ToxCast/Filer/NIEHS_Project/All_Materials/")

##----------------------------------------------------------------------------##
## Load/Save Current ToxCast Data
##----------------------------------------------------------------------------##

tc_export <- "ToxCast_Summary_Files"
ga_file <- file.path(tc_export, "AllResults_modl_ga_Matrix_141121.csv")
td_file <- file.path(tc_export, "AllResults_tested_Matrix_141121.csv")
zs_file <- file.path(tc_export, "AllResults_zscore_Matrix_141121.csv")
hc_file <- file.path(tc_export, "AllResults_hitc_Matrix_141121.csv")
ga <- data.matrix(read.csv(ga_file, header = TRUE, row.names = 1))
td <- data.matrix(read.csv(td_file, header = TRUE, row.names = 1))
zs <- data.matrix(read.csv(zs_file, header = TRUE, row.names = 1))
hc <- data.matrix(read.csv(hc_file, header = TRUE, row.names = 1))

ga <- 10^ga
ga[hc == 0] <- 1e6
ga[is.na(ga) & td == 1] <- 1e6
ga[zs <= 3] <- 1e6
ga <- -log10(ga/1e6)

zs[zs < 0] <- 0
zs[is.na(zs)] <- 1

ga <- ga*zs

models <- fread("all_models_141209.csv", header = TRUE)

chem <- fread(file.path(tc_export, "Chemical_Summary_141121.csv"), 
              header = TRUE)
setkey(chem, code)
chem <- chem[rownames(ga)]
if(!all(chem$code == rownames(ga))) stop("Chem map wrong.")

##----------------------------------------------------------------------------##


for(i in unique(models$Model)){
  
  cat(i, "...")
  assay <- models[Model == i, unique(aenm)]
  atemp <- ga[ , assay]
  atemp <- as.matrix(cbind(chem[ , list(paste0("DSSTox_GSID_", chid), 
                                        casn, 
                                        chnm)], 
                           atemp))
  itemp <- cbind(c(rep("", 4), "GSID"),
                 c(rep("", 4), "CASRN"),
                 c(rep("", 4), "NAME"),
                 t(models[Model == i, 
                          list(Weight, Slice, Type, Formula, aenm)]))
  output <- rbind(itemp, atemp)  
  
  write.table(output,
              file.path("Inputs",
                        "Models",
                        paste0(i, format(Sys.Date(), "_%y%m%d.csv"))),
              row.names = FALSE,
              col.names = FALSE,
              sep = ",")
              
  cat("done.\n")  
  
}



