##################################################################
##################################################################
#################### Toxpi .pdf creator ##########################
##################################################################
##################################################################

#Directions:
#This script will access the folder you designate (in.dir) and 
#create a .pdf file containing toxpi for every .csv file in the 
#folder you designate. It will save the .pdf files in the folder
#you designate under out.dir. 
#
#For more information on the parameters and an example input file 
#see: L:\Lab\NCCT_ToxCast\Filer\ToxPi\Support Files

rm(list=ls())
library(data.table)

## Set working directory to All_Materials
setwd("~/Shares/NCCT_ToxCast/Filer/NIEHS_Project/All_Materials/")

txpi.dir <- file.path("R_Scripts", "ToxPi")

signpost <- fread("signpostchems_vFiler.csv", header=TRUE)

#Parameters:
in.dir <- file.path("Inputs", "Models")
out.dir <- file.path("Outputs")
score.calc <- "radius" #"radius" or "area"
transform <- "none"
plot.chem <- NULL
label.plot.chem <- FALSE
n <- 30
plot.zeros <- FALSE
shift <- T
sort <- T
border <- 0
color <- NULL #c("#551A8B","#AB82FF","#1C86EE","#00FFFF","#7FFF00","#FFFF00","#FF8C00","#FF1493","#FF0000")
select.colors <- FALSE
trim.names <- TRUE
lab.offset <- 1
lab.cex <- 1
key.slice <- 1
key.lab.cex <- 0.8
plot.title <- FALSE
title.cex <- 2
GSID <- FALSE
rank.graph <- TRUE
refchem <- signpost[!is.na(DSSTox_GSID) & Signpost==1, DSSTox_GSID]
refchem.col <- "dodgerblue"
rank.graph.cex <- 1
rank.file <- TRUE

source(file.path(txpi.dir, "Scripts", "implement_vNIEHS.R"))


