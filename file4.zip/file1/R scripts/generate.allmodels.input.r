rm(list=ls())

setwd("~/Shares/NCCT_ToxCast/Filer/NIEHS_Project/All_Materials/")

out.dir <- file.path("Outputs")
mfiles <- grep("[0-9]+_summary.csv", dir(out.dir), value = TRUE)

dat <- data.frame("GSID"          = as.character(),
                  "CASRN"         = as.character(),
                  "Chemical_Name" = as.character())

for (mfile in mfiles) {
  model <- substr(mfile, 1, regexpr("_[0-9]+", mfile) - 1)
  print(model)
#   model <- switch(model,
#                   Feeding_Behavior_DC = "Feeding Behavior (Rodent)",
#                   Feeding_Behavior_SS = "Feeding Behavior (C. elegans)",
#                   Adipocyte_Differentiation = "Adipocyte Differentiation",
#                   Islet_Cell_MW = "Islet Cell (MW)",
#                   Islet_Cell_AH = "Islet Cell (AH)",
#                   Insulin_Sensitivity = "Insulin Sensitivity"
#                   )
  temp <- subset(read.csv(file.path(out.dir, mfile), header = TRUE),
                 select = c("GSID", "CASRN", "Chemical_Name", "score"))
  colnames(temp)[grep("score", colnames(temp))] <- model
  dat <- merge(dat, 
               temp, 
               by = c("GSID", "CASRN", "Chemical_Name"), 
               all.y = TRUE)
}

output <- rbind(matrix("", nrow = 4, ncol = ncol(dat)), 
                names(dat), 
                as.matrix(dat))
output[1, 4:ncol(output)] <- 1
output[2, 4:ncol(output)] <- colnames(dat)[4:ncol(output)]

write.table(output,
            file.path("Inputs", 
                      "Combined",
                      paste0("AllModels", format(Sys.Date(), "_%y%m%d.csv"))),
            row.names = FALSE,
            col.names = FALSE,
            sep = ",")
