## Set working directory to All_Materials
setwd("~/Shares/NCCT_ToxCast/Filer/NIEHS_Project/All_Materials/")

library(reshape2)
library(data.table)

##----------------------------------------------------------------------------##
## Load/Save Current ToxCast Data
##----------------------------------------------------------------------------##

tc_export <- "ToxCast_Summary_Files"
ga_file <- file.path(tc_export, "AllResults_modl_ga_Matrix_141121.csv")
td_file <- file.path(tc_export, "AllResults_tested_Matrix_141121.csv")
zs_file <- file.path(tc_export, "AllResults_zscore_Matrix_141121.csv")
hc_file <- file.path(tc_export, "AllResults_hitc_Matrix_141121.csv")
ch_file <- file.path(tc_export, "Chemical_Summary_141121.csv")
ae_file <- file.path(tc_export, "Assay_Summary_141121.csv")
ga <- data.matrix(read.csv(ga_file, header = TRUE, row.names = 1))
td <- data.matrix(read.csv(td_file, header = TRUE, row.names = 1))
zs <- data.matrix(read.csv(zs_file, header = TRUE, row.names = 1))
hc <- data.matrix(read.csv(hc_file, header = TRUE, row.names = 1))
ch <- fread(ch_file, header = TRUE)
ae <- fread(ae_file, header = TRUE)

ga <- 10^ga
ga[hc == 0] <- 1e6
ga[is.na(ga) & td == 1] <- 1e6
ga[zs <= 3] <- 1e6
ga <- -log10(ga/1e6)

nm <- zs
nm[hc == 0] <- 0
nm[is.na(zs) & td == 1] <- 0
nm[hc == 1 & zs <= 3] <- 1
nm[hc == 1 & zs > 3 & zs <= 6] <- 2
nm[hc == 1 & zs > 6 & zs <= 9] <- 3
nm[hc == 1 & zs > 9] <- 4

cl <- fread("ToxCast_Libraries.csv", header = TRUE)
nm <- nm[ch[chid %in% cl[clib == "ph1v2_ph2_all_toxcast", chid], code], ]
ga <- ga[ch[chid %in% cl[clib == "ph1v2_ph2_all_toxcast", chid], code], ]


ae[ , t1 := grepl("_down|_dn", aenm) & assay_source_name %in% c("APR", "BSK")]
ae[ , t2 := burst_assay == 1]
r <- ae[t1 | t2, aenm]
nm <- nm[ , !colnames(nm) %in% r]
ga <- ga[ , !colnames(ga) %in% r]


nm_cor <- cor(t(nm), use = "pairwise.complete.obs")
nm_res <- as.data.table(melt(nm_cor, as.is = TRUE))
setkey(nm_res, Var2)
setkey(ch, code)

ga_cor <- cor(t(ga), use = "pairwise.complete.obs")
ga_res <- as.data.table(melt(ga_cor, as.is = TRUE))
setkey(ga_res, Var2)
setkey(ch, code)

write.csv(nm,
          paste0("zscore_correlation_input", 
                 format(Sys.Date(), "_%y%m%d.csv")))
write.csv(nm_cor, 
          paste0("zscore_correlation_analysis_mat", 
                 format(Sys.Date(), "_%y%m%d.csv")))
write.csv(nm_res, 
          paste0("zscore_correlation_analysis_long", 
                 format(Sys.Date(), "_%y%m%d.csv")))

write.csv(ga,
          paste0("ac50_correlation_input", 
                 format(Sys.Date(), "_%y%m%d.csv")))
write.csv(ga_cor, 
          paste0("ac50_correlation_analysis_mat", 
                 format(Sys.Date(), "_%y%m%d.csv")))
write.csv(ga_res, 
          paste0("ac50_correlation_analysis_long", 
                 format(Sys.Date(), "_%y%m%d.csv")))






