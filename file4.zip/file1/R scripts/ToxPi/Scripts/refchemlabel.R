refchemlabel <- function(x,labels,color,cex=0.8,hoff=2,air=1.1,at=0,...){
  x <- drop(x)
  names(x) <- labels
  op <- par(xpd = TRUE)
  ord <- order(x)
  x <- x[ord]
  n <- length(x)
  pos <- numeric(n)
  hoff <- hoff*strwidth("m")
  ht <- air*abs(strheight(names(x),cex=cex))
  mid <- (n+1)%/%2
  pos[mid] <- x[mid]
  if (n>1){
    for(i in (mid+1):n){
      pos[i] <- max(x[i],pos[i-1]+ht[i])
    }
  }
  if (n>2){
    for(i in (mid-1):1){
      pos[i] <- min(x[i],pos[i+1]-ht[i])
    }
  }
  
  text(at-hoff,pos,names(x),pos=2,cex=cex,offset=0.2,col=color)
  segments(at,x,at-hoff*0.15,x)
  segments(at-hoff*0.15,x,at-hoff*0.85,pos)
  segments(at-hoff*0.85,pos,at-hoff,pos)
  
  par(op)
  invisible(pos[order(ord)])
}