data.parse <- function(data,GSID=FALSE,transform = "none"){
  
  if(length(which(is.na(data[1,])))>0){
    data <- data[,-which(is.na(data[1,]))]
  }
  
  data.header <- data[1:5,4:ncol(data)]
  
  slice.names <- unique(as.character(data.header[2,]))
  snames <- slice.names
  
  if(length(grep("#",slice.names))>0){
    GUI.format <- TRUE
  }else{GUI.format <- FALSE}
  
  slice.weights <- data.header[1,match(snames,data.header[2,])]
  slice.weights <- as.numeric(slice.weights)
  slice.weights <- slice.weights/sum(slice.weights)
  
  data.body <- data.frame(data[6:nrow(data),4:ncol(data)])
  data.body <- apply(data.body,2,as.numeric)
  data.body <- data.frame(data.body)
  
  slice.color <- NULL
  
  if(GUI.format){
    slice.info <- unique(as.character(data.header[2,1:ncol(data.header)]))
    slice.info <- strsplit(x=slice.info,split="#")
    snames <- sapply(slice.info,"[[",1)
    slice.info <- sapply(slice.info,"[[",2)
    slice.info <- strsplit(x=slice.info,split="@")
    slice.color <- sapply(slice.info,"[[",1)
    slice.color <- paste(rep("#",length(slice.color)),slice.color,sep="")
    col.func <- as.character(data.header[2,1:ncol(data.header)])
    col.func <- strsplit(x=col.func,split="@")
    col.func <- sapply(col.func,"[[",2)
    func.list <- list()
    for(i in 1:length(col.func)){
      func.list[[i]] <- function(x){}
      body(func.list[[i]]) <- parse(text=col.func[i])
    }
    data.body[data.body>1e6] <- 1e6
    data.body <- mapply(do.call,func.list,lapply(data.body,list))
  }else{
    if(transform == "zscore"){
      data.body <- apply(data.body,2,function(x){(x-mean(x))/sd(x)})
      data.body[is.na(data.body)] <- 0 
      data.body <- apply(data.body,2,function(x){x + min(x)})
    }else{
      if(transform == "log"){
        data.body[data.body>1e6] <- 1e6
        data.body <- apply(data.body,2,function(x){-log(x,10)+6})
      }
    }
  }
  
  L <- list()
  for(slice in snames){
    L[[slice]] <- cbind(data.body[,data.header[2,]==slice])
  }
  
  missing.dat <- sapply(L,function(x){apply(x,1,function(y){length(which(is.na(y)))})})
  nassay <- sapply(L,ncol)
  collapsed <- sapply(L,rowSums,na.rm=TRUE)
  
  if(GSID){
    rownames(collapsed) <- data[6:nrow(data),1]
  }else rownames(collapsed) <- data[6:nrow(data),3]
  
  collapsed <- cbind(GSID=data[6:nrow(data),1],CASRN=data[6:nrow(data),2],Chemical_Name=data[6:nrow(data),3],collapsed)
  
  output <- list(collapsed=collapsed,slice.weights=slice.weights,missing.dat=missing.dat,nassay=nassay,slice.color=slice.color)
    
  return(output)
  
}
