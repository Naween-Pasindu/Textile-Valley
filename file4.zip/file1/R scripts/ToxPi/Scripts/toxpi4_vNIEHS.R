toxpi4 <- function(data,shift=T,color=NULL,scale=T,title="",sort=F,weight=NULL,trim.names=F,lab.offset=1,lab.cex=1,title.cex=5,file.name=NULL,out.dir=NULL,rank.graph=FALSE,rank.file=FALSE,n=NULL,score.calc="radius",refchem=NULL,refchem.col=NULL,rank.graph.cex=0.1,border=0,plot.zeros=TRUE,plot.chem=NULL,label.plot.chem=FALSE,key.lab.cex=NULL,key.slice=1.8,plot.title=TRUE,...){
  
  cat("Executing toxpi function for: \"",file.name,"\" ...\n",sep="")
  
  #Save default graphics parameters
  op <- par(no.readonly=TRUE)
  
  #Close all open graphics devices
  graphics.off()
  
  #Set default output directory if none is given
  if(is.null(out.dir)){  
    out.dir <- getwd()
  }
  
  #Transform df to a matrix
  data <- data.frame(data)
  input.df <- as.matrix(data[,4:ncol(data)])
  input.df <- apply(input.df,2,as.numeric)
  rownames(input.df) <- data$GSID
       
  #Assign default file name if none is given
  if(is.null(file.name)){
    file.name <- paste("toxpi_fig",format(Sys.Date(),"_%y%m%d"),".pdf",sep="")
    count <- 1
    while(file.name%in%dir(out.dir)){
      file.name <- paste("toxpi_fig",format(Sys.Date(),"_%y%m%d"),"_",sprintf("%02d",count),".pdf",sep="")
      count <- count+1
    }
  }else{
    name <- paste(file.name,".pdf",sep="")
    count <- 1
    while(name%in%dir(out.dir)){
      name <- paste(file.name,"_",sprintf("%02d",count),".pdf",sep="")
      count <- count+1
    }
    file.name <- name
  }
  
  #Assign default colors when color=NULL
  if(is.null(color)){
    color <- colorRampPalette(c("#E41A1C","#377EB8","#4DAF4A","#984EA3","#FF7F00","#FFFF33"))(ncol(input.df))
    #color <- colorRampPalette(easy.colors(c(1,17,34,51,68,85)))(ncol(input.df))
  }else if(ncol(input.df)>length(color)){
    cat("Warning: the number of slices outnubers the number of given colors. Colors were recycled.\n")
  }
   
  #Scale the data
  if(scale){
    z <- apply(input.df,2,function(x)(x-min(x,na.rm=T))/diff(range(x,na.rm=T)))
  }else{ 
    z <- input.df
  }
  
  #Set Na to zero
  z[is.na(z)] <- 0
  
  #Define starting angles for toxpi slices
  if(is.null(weight)){
    angles <- seq.int(0,2*pi,2*pi/ncol(input.df))
  }else {
    angles <- 0
    for(i in 1:ncol(input.df)){
      a <- weight[i]*2*pi
      angles <- c(angles,a+angles[i])
    }
  }
  
  #Calculate area of toxpi and store in score vector
  if(score.calc=="area"){
    score <- rep(0,nrow(input.df))
    for(i in 1L:nrow(input.df)){
      j.score <- as.vector(0)  
      for(j in 1L:ncol(input.df)){
        j.score <- c(j.score,z[i,j]^2*pi*weight[j])
      }
      score[i] <- sum(j.score)
      if(!exists("slice.score")){
        slice.score <- j.score
      }else{
        slice.score <- rbind(slice.score,j.score)
      }
    }
  }else{
    score <- rep(0,nrow(input.df))
    for(i in 1L:nrow(input.df)){
      j.score <- as.vector(0)  
      for(j in 1L:ncol(input.df)){
        j.score <- c(j.score,z[i,j]*weight[j])
      }
      score[i] <- sum(j.score)
      if(!exists("slice.score")){
        slice.score <- j.score
      }else{
        slice.score <- rbind(slice.score,j.score)
      }
    }
  }

  #Add score column to z
  z <- cbind(z,score)
  
  #Name the slice.score columns
  slice.score <- slice.score[,-1]
  colnames(slice.score) <- colnames(input.df)
  
  #Sort the chemicals by score
  z <- data.frame(z,GSID=data$GSID,name=data$Chemical_Name,CASRN=data$CASRN)
  rownames(z) <- data$GSID
  z$name <- as.character(z$name)
  if(sort){
    z <- z[order(score,decreasing=TRUE),]
  }
  
  #Trim chemical names over 35 characters
  if(trim.names){
    z$name[which(nchar(z$name)>35)] <- paste(strtrim(z$name[which(nchar(z$name)>35)],35),"...")
    z$name[which(nchar(z$name)>35)] <- as.character(z$CASRN[which(nchar(z$name)>35)])
  }
  
  
  #Set the number of plots
  if(is.null(plot.chem)){
    if(is.null(n)){
      if(plot.zeros){
        n <- nrow(input.df)
      }else{
        n <- length(which(z$score>0))  
      }
    }
  }else{
    n <- length(plot.chem)
  }
  if(n > nrow(input.df)){
    n <- nrow(input.df)
  }
  
  #Define plot and refchem column in z
  z <- data.frame(z,plot=rep(FALSE,nrow(z)),refchem=rep(FALSE,nrow(z)),refchem.col=rep("Black",nrow(z)))
  if(is.null(plot.chem)){
    if(plot.zeros){
      z$plot[1:n] <- TRUE
    }else{
      z$plot[which(z$score>0)][1:n] <- TRUE
    }
  }else{
    z$plot <- z$GSID %in% plot.chem
    if(!plot.zeros){
      n <- n-length(which(z$score==0&z$plot==TRUE))
      z$plot[which(z$score==0&z$plot==TRUE)] <- FALSE
    }
  }
  
  if(label.plot.chem){
    z$refchem <- z$GSID %in% refchem | z$GSID %in% plot.chem
  }else{
    z$refchem <- z$GSID %in% refchem
  }
  
  if(length(which(z$refchem))==0){
    refchem <- NULL
  }
    
  #Define refchem.col column in z
  if(length(which(z$refchem))>0){
    z$refchem.col <- as.character(z$refchem.col)
    refchem.col.vec <- match(refchem,z$GSID)
    refchem.rm <- which(is.na(refchem.col.vec))
    if(length(refchem.rm)>0){
      refchem.col <- refchem.col[-refchem.rm]
      refchem.col.vec <- refchem.col.vec[-refchem.rm]
    }
    if(!is.null(refchem.col)){
      z$refchem.col[refchem.col.vec] <- refchem.col
    }
  }
  
  zp <- z[which(z$plot==TRUE),]
  
  #Define the # of plots in the x and y directions
  xplots <- ceiling(sqrt(n))+1
  yplots <- floor(sqrt(n))
  #If the number of excess plots is greater than the number of 
  #columns we want to remove one row of plots 
  if((xplots*yplots-n)>xplots){
    yplots = yplots-1
  }
  
  #Set plot dimensions
  width <- c(0,xplots*3+1)
  height <- c(0,yplots*3+1)
  
  #Create pdf to save the plot into
  pdf(file=file.path(out.dir,file.name),width=width[2],height=height[2]+8,pointsize=18)
  #png(file=paste(out.dir,sub(".pdf",".png",file.name),sep=""),width=width[2],height=height[2]+8,pointsize=18,units="in",res=800)
  
  #Create vectors for  toxpi center coordinates
  x0cord <- rep(seq(from=2,to=width[2]-2,by=3),yplots)
  y0cord <- rep(seq(from=height[2]-2,to=2,by=-3),rep(xplots,yplots))
  #Shift down every other column
  centers <- cbind(x0cord,y0cord)
  if(shift){
    for(i in 1:length(centers[,1])){
      if(!centers[i,1]%%2==0){
        centers[i,2] <- centers[i,2]-0.5
      }
    }
    #Restore ycord with shifted points
    y0cord <- centers[,2]
  }
  
  #Set the grid dimensions and establish grid for graphics
  if(plot.title){
    grid.matrix <- matrix(c(1,1,1,4,1,1,1,4,1,1,1,3,1,1,1,3,1,1,1,2),4,5)
  }else{
    grid.matrix <- matrix(c(1,1,1,3,1,1,1,3,1,1,1,3,1,1,1,2,1,1,1,2),4,5)
  }
  layout(mat=grid.matrix,heights=c(rep(height[2]/3,3),8))
  
  #Set graph margins to 0
  par(mar=rep(0,4))
  
  #Create plot region
  plot(0,type="n",xlim=width,ylim=height,axes=F,xlab="",ylab="")
  
  
  #Draw the toxpi
  for(i in 1:n){
    x1cord <- as.vector(NA)
    y1cord <- as.vector(NA)
    for(j in 1:ncol(input.df)){
      theta <- seq(angles[j],angles[j+1],length.out=360/(2*pi/(angles[j+1]-angles[j])))
      x1cord <- c(x1cord,x0cord[i],zp[i,j]*cos(theta)+x0cord[i],NA)
      y1cord <- c(y1cord,y0cord[i],zp[i,j]*sin(theta)+y0cord[i],NA)
    }
    polygon(x=x1cord,y=y1cord,col=color,lty=border)
  }
  
  #Set label coordinates for non-refchem
  lab.xcord <- x0cord[which(zp$refchem==FALSE)]
  lab.ycord <- y0cord[which(zp$refchem==FALSE)]-lab.offset
  
  #Draw labels for non-refchem
  if(length(lab.xcord>0)){
    text(x=lab.xcord,y=lab.ycord,labels=paste(zp$name[which(zp$refchem==FALSE)]," (",round(zp$score[which(zp$refchem==FALSE)],3),")"),pos=1,cex=lab.cex)
  }
  
  #Set label coordinates for refchem
  lab.xcord <- x0cord[which(zp$refchem==TRUE)]
  lab.ycord <- y0cord[which(zp$refchem==TRUE)]-lab.offset
  
  #Draw labels for refchem
  if(length(lab.xcord>0)){
    text(x=lab.xcord,y=lab.ycord,labels=paste(zp$name[which(zp$refchem==TRUE)]," (",round(zp$score[which(zp$refchem==TRUE)],3),")"),pos=1,cex=lab.cex,font=2,col="dodgerblue")#color was royalblue1 and font was 2
  }

  par(mar=c(5,0,0,5),pty="s")
  plot(0,type="n",xlim=c(0,5),ylim=c(0,5),axes=F,xlab="",ylab="")
  
  #Assign location for legend
  key.cord <- c(2.5,2.5)
  
  #Draw legend toxpi
  key.slice <- key.slice
  key.x <- as.vector(NA)
  key.y <- as.vector(NA)
  for(j in 1:ncol(input.df)){
    theta <- seq(angles[j],angles[j+1],length.out=360/(2*pi/(angles[j+1]-angles[j])))
    key.x <- c(key.x,key.cord[1L],key.slice*cos(theta)+key.cord[1L],NA)
    key.y <- c(key.y,key.cord[2L],key.slice*sin(theta)+key.cord[2L],NA)
  }
  polygon(x=key.x,y=key.y,col=color,lty=border)
  
  #Annotate legend
  key.lab <- key.slice + 0.05
  key.lab.angles <- rep(0,ncol(input.df))
  for(i in 1L:ncol(input.df)){
    key.lab.angles[i] <- angles[i] + (angles[i+1L]-angles[i])/2
  }
  
  for(i in 1L:ncol(input.df)){
    key.lab.x <- key.cord[1]+key.lab*cos(key.lab.angles[i])
    key.lab.y <- key.cord[2]+key.lab*sin(key.lab.angles[i])
    key.adj <- c(
      if(key.lab.angles[i]>=pi/2 && key.lab.angles[i]<=3*pi/2){
        1
      }else 0,
      if(key.lab.angles[i]<=pi){
        0
      }else 1
    )
    if(is.null(key.lab.cex)){
      key.lab.cex <- lab.cex
      if(key.adj[1]==1){
        while(key.lab.x-strwidth(colnames(input.df)[i],cex=key.lab.cex)<0){
          key.lab.cex <- key.lab.cex-0.1
        }
      }else{
        while(key.lab.x+strwidth(colnames(input.df)[i],cex=key.lab.cex)>5){
          key.lab.cex <- key.lab.cex-0.1
        }
      }
    }
    text(x=key.lab.x,y=key.lab.y,adj=key.adj,cex=key.lab.cex,
         labels=switch(colnames(input.df)[i],
                       Feeding_Behavior_DC = "Feeding Behavior (Rodent)",
                       Feeding_Behavior_SS = "Feeding Behavior (C. elegans)",
                       Adipocyte_Differentiation = "Adipocyte Differentiation",
                       Islet_Cell_MW = "Islet Cell (MW)",
                       Islet_Cell_AH = "Islet Cell (AH)",
                       Insulin_Sensitivity = "Insulin Sensitivity",
                       colnames(input.df)[i]
         ))
  }
  
  #Plot the rank by toxpi score
  if(rank.graph){
    par(mar=c(10,15,6.1,2.1),pty="m")
    z <- z[order(z$score,decreasing=TRUE),]
    rank <- seq(from=1,to=nrow(z),by=1)
    z <- cbind(z,rank)
    plot(x=z$score,y=z$rank,ylim=rev(range(c(1:nrow(z)))),axes=FALSE,ylab="",xlab="Toxpi Score",frame.plot=FALSE,cex.lab=lab.cex,xlim=c(0,max(z$score)))
    axis(side=1,labels=TRUE)
    if(nrow(zp)<nrow(z)){
      points(x=z$score[which(z$plot==TRUE)],y=z$rank[which(z$plot==TRUE)],col="Red")
    }
    if(is.null(refchem)){
      axis(side=2,labels=z$name,cex.axis=rank.graph.cex,at=seq(1,nrow(z),1),las=1,tick=FALSE)
    }else{
      refchemlabel(x=z$rank[which(z$refchem==TRUE)],labels=z$name[which(z$refchem==TRUE)],air=1.2,hoff=2,at=max(z$score)*-0.05,color="Black")#z$refchem.col[which(z$refchem==TRUE)])
      axis(side=2,labels=FALSE,lwd.ticks=0)
      points(x=z$score[which(z$refchem==TRUE)],y=z$rank[which(z$refchem==TRUE)],col=z$refchem.col[which(z$refchem==TRUE)],cex=1.5,pch=16)#col was royalblue1
    }
    #abline(h=max(z$rank))
    #lines(density(z$score)$y*(-1)+max(z$rank)~density(z$score)$x,col="gold",lwd=2)
  }else{
    par(mar=rep(0,4))
    plot(0,type="n",axes=FALSE,xlab="",ylab="")
  }
  
  #Plot the title plot
  if(plot.title){
    par(mar=rep(0,4))
    plot(0,type="n",xlim=c(0,1),ylim=c(0,1),axes=FALSE,xlab="",ylab="")
    text(x=0.5,y=0.5,labels=as.character(title),cex=title.cex)  
  }
    
  #Close the pdf device window
  graphics.off()
  
  #Write a rank and score summary file
  if(rank.file){
    rf <- cbind(data[,1:3],score,slice.score)
    rf <- data.frame(rf)
    rf <- rf[order(score,decreasing=TRUE),]
    rank <- rank(-rf$score,ties.method="min")
    rf <- cbind(rf[,1:4],rank,rf[5:ncol(rf)])
    rf.name <- sub(x=file.name,pattern=".pdf",replacement="_summary.csv")
    write.csv(x=rf,file=file.path(out.dir,rf.name),row.names=FALSE)
    cat("Summary saved as: \"",rf.name,"\" under: ",out.dir,"\n",sep="")
  }
  
  #Print completion message
  cat("Pdf saved as: \"",file.name,"\" under: ",out.dir,"\n\n",sep="")
  
}
