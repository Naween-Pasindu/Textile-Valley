
file.grep <- ".csv"
scripts.dir <- file.path(txpi.dir, "Scripts")

source(file.path(scripts.dir, "data.parse.R"))
source(file.path(scripts.dir, "toxpi4_vNIEHS.R"))
source(file.path(scripts.dir, "easy.colors.R"))
source(file.path(scripts.dir, "refchemlabel.R"))

dat.files <- dir(in.dir, pattern = file.grep)
dat.files <- dat.files[!grepl("summary", dat.files)]

  
if(select.colors) source(file.path(scripts.dir, "color.select.R"))


for(infile in dat.files){
  dat <- as.data.frame(fread(file.path(in.dir, infile), header = FALSE))
  
  dat.list <- data.parse(dat, GSID = GSID)
    
  if(exists("individual")){
    if(individual=="y"){
      source(file.path(scripts.dir, "color.select.ind.R"))
    }
  }
  
  if(!is.null(dat.list[["slice.color"]])) color <- dat.list[["slice.color"]]
  
  infile <- sub(x = infile, pattern = ".csv", replacement = "")

  toxpi4(data=dat.list[[1]],weight=dat.list[[2]],file.name=infile,out.dir=out.dir,shift=shift,color=color,sort=sort,title=infile,lab.offset=lab.offset,title.cex=title.cex,trim.names=trim.names,lab.cex=lab.cex,rank.file=rank.file,rank.graph=rank.graph,n=n,score.calc=score.calc,refchem=refchem,refchem.col=refchem.col,rank.graph.cex=rank.graph.cex,plot.zeros=plot.zeros,plot.chem=plot.chem,border=border,label.plot.chem=label.plot.chem,key.lab.cex=key.lab.cex,plot.title=plot.title,key.slice=key.slice)

}