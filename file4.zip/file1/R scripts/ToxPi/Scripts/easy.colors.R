easy.colors <- function(col.vec){
  palette(rainbow(n=100,start=0,end=1))
  for(i in 1:length(col.vec)){
    if(!exists("col.vec.2")){
      col.vec.2 <- palette()[col.vec[i]]
    }else{
      col.vec.2 <- c(col.vec.2,palette()[col.vec[i]])
    }
  }
  return(col.vec.2)
}