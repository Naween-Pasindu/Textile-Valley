cat("Do you want to selct colors for each file individually? (y/n)",fill=TRUE)
individual <- readLines(n=1)
if(individual=="n"){
    do.again <- "y"
  while(do.again=="y"){
    cat("How many slices do you have? ")
    sn <- readLines(n=1)
    sn <- as.numeric(sn)
    pie(rep(1,100),col=rainbow(100,start=0,end=1),labels=seq(1,100,1),cex=.3)
    cat("Review the color chart in the plot window and select the\n colors you want for your toxpi. Enter the colors one at a time\n hitting enter after each color:",fill=TRUE)
    color <- readLines(n=sn)
    color <- as.numeric(color)
    color <- easy.colors(color)
    pie(rep(1,length(color)),col=color,labels=color)
    cat("Review your color choices in the plot window. Do you want\n to reselct? (y/n):",fill=TRUE)
    do.again <- readLines(n=1)
  }
}
