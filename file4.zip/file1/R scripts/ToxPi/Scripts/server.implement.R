
file.grep <- ".csv"
scripts.dir <- "/share/home/dfiler/ToxCast/ToxPi/Scripts/"

source(paste(scripts.dir,"data.parse.R",sep=""))
source(paste(scripts.dir,"toxpi4.R",sep=""))
source(paste(scripts.dir,"easy.colors.R",sep=""))
source(paste(scripts.dir,"refchemlabel.R",sep=""))

data.files <- dir(in.dir,pattern=file.grep)
if(length(grep("summary",data.files))){
  data.files <- data.files[-grep("summary",data.files)]
}
  
if(select.colors){
  source(paste(scripts.dir,"color.select.R",sep=""))
}

for(i in 1:length(data.files)){
  data <- read.csv(paste(in.dir,data.files[i],sep=""),header=F,as.is=TRUE)
  
  data.list <- data.parse(data,GSID=GSID)
    
  if(exists("individual")){
    if(individual=="y"){
      source(paste(scripts.dir,"color.select.ind.R",sep=""))
    }
  }
  
  tempcolor <- color
  
  if(length(data.list)>2){
    tempcolor <- data.list[[3]]
  }
  
  data.files[i] <- sub(x=data.files[i],pattern=".csv",replacement="")

  toxpi4(data=data.list[[1]],weight=data.list[[2]],file.name=data.files[i],out.dir=out.dir,shift=shift,color=tempcolor,sort=sort,title=data.files[i],lab.offset=lab.offset,title.cex=title.cex,trim.names=trim.names,lab.cex=lab.cex,rank.file=rank.file,rank.graph=rank.graph,n=n,score.calc=score.calc,refchem=refchem,refchem.col=refchem.col,rank.graph.cex=rank.graph.cex,plot.zeros=plot.zeros,plot.chem=plot.chem,border=border,label.plot.chem=label.plot.chem,key.lab.cex=key.lab.cex,plot.title=plot.title,key.slice=key.slice)

}